#include <stdio.h>
#include "cs3421_emul.h"

int main(int argc; char *argv[])
{
	printf(HW_STRING);
	return 0;
}
