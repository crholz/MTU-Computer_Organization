#define HW_STRING "Hello world!\n"
