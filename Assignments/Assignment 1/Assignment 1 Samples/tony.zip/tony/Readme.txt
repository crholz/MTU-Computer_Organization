[Sample text. Be sure to identify any and all known problems, and any
non-standard libraries or packages used, and how to retrieve & install them.]

I had some problems getting register RH to work, but everything else seems
fine.
